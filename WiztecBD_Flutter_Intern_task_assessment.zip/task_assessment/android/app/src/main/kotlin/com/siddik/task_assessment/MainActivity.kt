package com.siddik.task_assessment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
