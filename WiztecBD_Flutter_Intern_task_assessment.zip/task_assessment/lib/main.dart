import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main(){
  SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
    statusBarColor:Colors.green.shade300,
    systemNavigationBarColor:Colors.green.shade400,
  ));
  runApp(MyApp());
}

class MyApp extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Home(),
    );
  }
}

class Home extends StatefulWidget{
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {

  final scaffoldKey = GlobalKey<ScaffoldState>();
  //key for scaffold, required to manually open/close drawer

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
        key: scaffoldKey,
        appBar: AppBar(
          title: Text("Table Data"),
        ),
        drawer: Drawer(
          child: SafeArea(

            child:SingleChildScrollView(

                child:Column(
                  children: [
                    const UserAccountsDrawerHeader(
                        accountName: Text('Demo Limited Company'),
                        accountEmail: Text('.'),
                    currentAccountPicture:CloseButton(onPressed: SocketException.closed),
                    ),
                    ExpansionTile(
                      title: Text("Purchase"),
                      leading: Icon(Icons.person), //add icon
                      childrenPadding: EdgeInsets.only(left:60), //children padding
                      children: [
                        ListTile(
                          title: Text("Purchase List"),
                          onTap: (){
                            //action on press
                          },
                        ),

                        ListTile(
                          title: Text("Order List"),
                          onTap: (){
                            //action on press
                          },
                        ),
                        ListTile(
                          title: Text("Vat List"),
                          onTap: (){
                            //action on press
                          },
                        ),
                        ListTile(
                          title: Text("Purchase Unit"),
                          onTap: (){
                            //action on press
                          },
                        ),
                        ListTile(
                          title: Text("Purchase Report"),
                          onTap: (){
                            //action on press
                          },
                        ),

                        //more child menu
                      ],
                    ),
                    ExpansionTile(
                      title: Text("Sell"),
                      leading: Icon(Icons.sell), //add icon
                      childrenPadding: EdgeInsets.only(left:60), //children padding
                      children: [
                        ListTile(
                          title: Text("Add 1"),
                          onTap: (){
                            //action on press
                          },
                        ),

                        ListTile(
                          title: Text("Add 2"),
                          onTap: (){
                            //action on press
                          },
                        ),

                        //more child menu
                      ],
                    ),
                    ExpansionTile(
                      title: Text("Stock / Inventory"),
                      leading: Icon(Icons.inventory),//add icon
                      childrenPadding: EdgeInsets.only(left:60), //children padding
                      children: [
                        ListTile(
                          title: Text("Add 1"),
                          onTap: (){
                            //action on press
                          },
                        ),

                        ListTile(
                          title: Text("Add 2"),
                          onTap: (){
                            //action on press
                          },
                        ),

                        //more child menu
                      ],
                    ),
                  ],
                )
            )
          ),
        ),

        body:SingleChildScrollView(
          child:Column(
            children: [
              Container(
                width: 263,
                height: 32,
                color:Colors.green,
                child: Text('Due'),
                margin: EdgeInsets.only(top: 5,left: 16),
              ),
              Container(
                width: 263,
                height: 18,
                color:Colors.white,
                child: Text('Previous Due 01 January 2022'),
                margin: EdgeInsets.only(top: 5,left: 31),
              ),
              Container(
                width: 263,
                height: 32,
                color:Colors.green,
                child: Text('Purchase'),
                margin: EdgeInsets.only(top: 5,left: 16),
              ),
              Container(
                width: 263,
                height: 18,
                color:Colors.green.shade50,
                child: Text('Invoice Date: 01 January 2022'),
                margin: EdgeInsets.only(top: 5,left: 31),
              ),
              Container(
                width: 263,
                height: 18,
                color:Colors.green.shade50,
                child: Text('Invoisce No: 5386328'),
                margin: EdgeInsets.only(top: 2,left: 31),
              ),
              Container(
                width: 263,
                height: 18,
                color:Colors.white,
                child: Text('Test product 01        |  '),
                margin: EdgeInsets.only(top: 2,left: 31),
              ),
              Container(
                width: 263,
                height: 18,
                color:Colors.white,
                child: Text('200 pcs x 200           |         ট40000'),
                margin: EdgeInsets.only(top: 2,left: 31),
              ),
              Container(
                width: 263,
                height: 18,
                color:Colors.white,
                child: Text('Test product 01        |  '),
                margin: EdgeInsets.only(top: 2,left: 31),
              ),
              Container(
                width: 263,
                height: 18,
                color:Colors.white,
                child: Text('20  pcs x 300            |         ট60000'),
                margin: EdgeInsets.only(top: 2,left: 31),
              ),
              Container(
                width: 263,
                height: 18,
                color:Colors.white,
                child: Text('Test product 01        |  '),
                margin: EdgeInsets.only(top: 2,left: 31),
              ),
              Container(
                width: 263,
                height: 18,
                color:Colors.white,
                child: Text('20  pcs x 200            |          ট4000'),
                margin: EdgeInsets.only(top: 2,left: 31),
              ),
              Container(
                width: 263,
                height: 32,
                color:Colors.green,
                child: Text('Payment'),
                margin: EdgeInsets.only(top: 5,left: 16),
              ),
              Container(
                width: 263,
                height: 18,
                color:Colors.green.shade50,
                child: Text('Invoice Date: 01 January 2022'),
                margin: EdgeInsets.only(top: 5,left: 31),
              ),
              Container(
                width: 263,
                height: 18,
                color:Colors.green.shade50,
                child: Text('Invoisce No: 5386328'),
                margin: EdgeInsets.only(top: 2,left: 31),
              ),
              Container(
                width: 263,
                height: 32,
                color:Colors.green,
                child: Text('Return'),
                margin: EdgeInsets.only(top: 5,left: 16),
              ),
              Container(
                width: 263,
                height: 18,
                color:Colors.green.shade50,
                child: Text('Invoice Date: 01 January 2022'),
                margin: EdgeInsets.only(top: 5,left: 31),
              ),
              Container(
                width: 263,
                height: 18,
                color:Colors.green.shade50,
                child: Text('Invoisce No: 5386328'),
                margin: EdgeInsets.only(top: 2,left: 31),
              ),
              Container(
                width: 263,
                height: 18,
                color:Colors.green.shade50,
                child: Text('Return Date: 01 January 2022'),
                margin: EdgeInsets.only(top: 5,left: 31),
              ),
              Container(
                width: 263,
                height: 18,
                color:Colors.green.shade50,
                child: Text('Return No: 5386328'),
                margin: EdgeInsets.only(top: 2,left: 31),
              ),
              Container(
                width: 263,
                height: 48,
                color:Colors.green,
                child:Center(child:Text(' + Pay the balance')),
                margin: EdgeInsets.only(top: 5,left: 16),
              ),
            ],
          )

        )

    );
  }
}

